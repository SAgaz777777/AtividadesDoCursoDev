

n = int(input("informe o número desejado: "))

i = 1

while i <= 10:
    r = n * i
    print(F"{n} X {i} = {r}")
    i+=1