produtos = ["camisetas", "calças", "blusas", "sapatos"]


opcao = int(input("selecione o produto que deseja: "))

for i, produto in enumerate(produtos, 1):
    if opcao == i:
        print(F"{i} - {produto}")
        print("produto selecionado com sucesso")

        break

else:
    print("produto inesxitente")
