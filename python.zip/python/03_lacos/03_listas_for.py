

print("")
print(f"{"=" * 10}LISTAS DE LOJAS {"=" * 10}")
print("")


lojas = ("Santo andré","São bernado do campo", "São caetano do sul", "diadema", "mauá", "osasco" )

for loja in lojas:
    print(loja)
    
print("")