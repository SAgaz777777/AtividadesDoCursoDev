alunos = ["miguel", "arthur","enzo", "emanuelly", "karol"]

for i, aluno in  enumerate(alunos, 1):
    print(f"{i} - {aluno}")