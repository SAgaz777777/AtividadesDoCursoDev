n = int(input("informe o número desejado: "))

print(f"tabuada do {n}: ")

for i in range(0,11):
    r = n * i

    print(f"{n} X {i} = {r}")
