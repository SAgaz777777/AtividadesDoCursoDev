for i in range(0,10):
    # i = i + 1
    i+=1
    print(i)