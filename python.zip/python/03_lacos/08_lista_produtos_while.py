print("")
print(f"{'=' * 10} LISTA DE PRODUTOS {'=' * 10}")
print("")

produtos = ["camisetas", "calças", "blusas", "sapatos"]

print("Lista completa de produtos: ")
i = 0
while i < len(produtos):
    
    print(f"{i + 1} - {produtos[i]}") 
    i += 1

print("")


inicio = int(input("Digite o número inicial: "))
fim = int(input("Digite o número final: "))

print()

if inicio < 1 or fim > len(produtos) or inicio > fim:
    print("Intervalo inválido!")
    print("Verifique os valores digitados.")
else:
    print(f"Produtos do {inicio} ao {fim}:\n")

    i = inicio - 1
    contador = inicio
    while i < fim:
        
        print(f"{contador} - {produtos[i]}")
        i += 1
        contador += 1 

print("")
print("Operação realizada com sucesso!")
print("")