print("======= LOJAS =======")
print("")
print("1 - Santo andré")
print("2 - São Bernardo do Campo")
print("3 - São Caetano do Sul")
print("4 - Diadema")
print("5 - Maua")

loja = int(input("informe o código da loja: "))

if loja == 1:
    print("santo andré")
elif loja == 2:
    print("São Bernardo do Campo")
elif loja == 3:
    print("São Caetano do Sul")
elif loja == 4:
    print("Diadema")
elif loja == 5:
    print("Maua")
else:
    print("código inválido")
   
print("")
print(" ========== FIM ==========")
print("")
