cor = input("informe a cor desejada: ")

if cor == "verde":

   print("pode passar")

elif cor == "amarelo":

   print("atenção")

elif cor == "vermelho":

   print("pare")

else:
   
      print("cor indefinida")
      
   
