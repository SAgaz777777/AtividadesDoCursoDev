dia = input("informe o dia da semana: ")

def dia_da_semana(dia):

 match dia:

    case "domingo" | "sábado":
        return "fim de semana."
    
    case "segunda" | "terça" | "quarta" | "quinta" | "sexta":
        return "dia útil."
    
    case _:
        return "valor inválido"
    
print(dia_da_semana(dia))

print("")
print("============ FIM ============")
    

