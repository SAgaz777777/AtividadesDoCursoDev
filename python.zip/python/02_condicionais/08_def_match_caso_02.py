sabor = int(input('selecione o sabor desejado: '))


def sabor_pizza(sabor):
    match sabor:
        case 1:
            return print("mussarela")
        case 2:
            return print("calabresa")
        case 3:
            return print("frango c/ catupiri")
        case 4:
            return print("atum")
        case _:
            return print("sabor inválido")

sabor_pizza(sabor)

print("")
print("============ FIM ============")
    