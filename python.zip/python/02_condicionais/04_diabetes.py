
valor = int(input("informe o valor de mg/dl: "))

teste = ("situação: normal") if valor < 100 else "situação: pré-diabetes" if valor in range(100, 125) else "diabetes"

print(teste)