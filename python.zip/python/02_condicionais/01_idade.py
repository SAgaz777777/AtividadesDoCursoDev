nome = input("informe o seu nome: ")
idade = int(input("informe sua idade: "))

if idade >=18:
    print(f"olá, {nome}! você tem {idade} anos. maior de idade")
else:
       print(f"olá, {nome}! você tem {idade} anos. menor de idade")