velocidade = int(input("informe a velocidade: "))

alerta = "alta velocidade! multado" if velocidade > 60 else "no limite de volocidade."

print(alerta)