nome1 = "miguel"
nome2 = "arthur"

print(len(nome1))
print(len(nome2))

