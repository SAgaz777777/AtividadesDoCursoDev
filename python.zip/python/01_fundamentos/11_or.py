idade_arthur = 18
idade_miguel = 17

if idade_miguel >= 18 or idade_arthur >= 18:
    print("pelo menos um dos dois é maior de idade.")
else:
    print("arthur e miguel não são maiores de idade. ")
