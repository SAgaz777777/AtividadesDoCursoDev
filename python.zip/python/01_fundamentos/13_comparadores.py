carro_arthur = "astra"
carro_bia = "astra"
carro_miguel = "vectra"

if carro_arthur == carro_bia: 
    print(f"{carro_arthur} - {carro_bia} = mesmo carro.")
else:
    print(f"{carro_arthur} - {carro_bia} = carros diferentes.")

print("=" * 30)
print("miguel e arthur")

if carro_arthur == carro_miguel:
    print(f"{carro_arthur} - {carro_miguel} = mesmo carro.")
else:
    print(f"{carro_arthur} - {carro_miguel} = carros diferentes.")
