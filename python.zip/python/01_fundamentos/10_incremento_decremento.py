n1 = 10
n1 +=5

print("incremento: ")
print(n1)

print("")

n2 = 24
n2 -=13
print("decremento: ")

print(n2)