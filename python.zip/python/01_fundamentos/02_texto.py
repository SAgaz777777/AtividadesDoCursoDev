nome = 'arthur'
idade = '17'

# 01
print("o meu nome é " + nome + " e tenho " +str(idade)+ " anos.")
# 02
print("o meu nome é {} e tenho {} anos. " .format(nome, idade))
# 3
print(f"o meu nome é {nome} e tenho {idade} anos. ")