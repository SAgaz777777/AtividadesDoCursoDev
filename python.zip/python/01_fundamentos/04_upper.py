mensagem = "eu gosto de python"

nova_mensagem = mensagem.upper()

print(nova_mensagem)