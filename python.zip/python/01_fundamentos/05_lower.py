mensagem = "eu gosto de python"

nova_mensagem = mensagem.lower()

print(nova_mensagem)