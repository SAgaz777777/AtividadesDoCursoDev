idade_arthur = 18
idade_miguel = 17 

if idade_miguel >= 18 and idade_arthur >= 18:
    print("os dois são maiores de idade.")
else:
    print("arthur e miguel não são maiores de idade. ")
