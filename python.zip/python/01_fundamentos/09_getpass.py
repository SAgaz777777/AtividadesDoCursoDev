import getpass as gtp

usuario = input("nome do usuario: ")
senha = gtp.getpass("digite a sua senha")


if len(senha) >=6:
    print(f"usuario cadastrado com sucesso!")
else:
    print(f"Atenção, a senha deve ter no mínimo 6 caracteres")