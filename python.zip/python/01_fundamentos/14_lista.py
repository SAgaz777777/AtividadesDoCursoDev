carros = ["astra", "vectra", "kadet","opala"]

carro1 = "astra"
carro2 = "kadet"

print(carro1 in carros) 
print(carro2 in carros)
