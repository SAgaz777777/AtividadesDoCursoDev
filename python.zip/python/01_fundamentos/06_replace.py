mensagem = "quero aprender em Java"

nova_mensagem = mensagem.replace("java","python")

print(nova_mensagem)