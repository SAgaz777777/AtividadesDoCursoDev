
print('soma de dois números')
print("")
n1 = float(input('informe o primeiro número: '))
n2 = float(input('informe o segundo número: '))

soma = n1 + n2

print("")
print((f"o resulta calculado é {soma}."))