mensagem = "estou apredendo python no curso"

lista_mensagem = mensagem.split(' ')

print(lista_mensagem[4])