import streamlit as st
import pandas as pd


st.title("Grafico de linhas")



df = pd.DataFrame({
    "x" : [1, 2, 3, 4, 5],
    "y" : [10, 20, 15, 30, 25]
})


st.line_chart(df.set_index("x"))