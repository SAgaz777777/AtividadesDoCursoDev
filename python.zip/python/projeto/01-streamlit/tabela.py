import streamlit as st
import pandas as pd

st.title("tabela")


df = pd.read_csv("dados.csv")

st.dataframe(df)

st.subheander("vendas totais por dia")

vendas_por_dia = df.groupby("data")["quantidade"].sum().reset_index()

st.line_chart(vendas_por_dia.rename(columns={"data" : "index"}).set_index("index"))

st.subheader("faturamneto futuro")

df["faturamento"] = df["quantidade"] * df["preco"]

faturamento_produto = df.groupby("produto")["faturamento"].sum().reset_index()



st.bar_chart(faturamento_produto.set_index("produto"))


